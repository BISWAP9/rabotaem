<?php
session_start();
$url = explode("/", $_SERVER['REQUEST_URI']);

if (!empty($content))
	require_once("rabotaem.html");
